package Scrabble.Utils.Exceptions;

public class WrongFormatException extends InvalidMoveException{

    public WrongFormatException(String msg){
        super(msg);
    }

}
