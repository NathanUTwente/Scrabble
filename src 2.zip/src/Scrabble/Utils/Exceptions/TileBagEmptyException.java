package Scrabble.Utils.Exceptions;

public class TileBagEmptyException extends InvalidMoveException {
    public TileBagEmptyException(String msg) {
        super(msg);
    }
}
