package Scrabble.Tests;

import Scrabble.Model.BoardModel.Board;
import Scrabble.Model.BoardModel.Tile;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class BoardTest {



    void newBoardIsEmpty(){
        Board board = new Board();
        for (int i = 0; i < 16; i++) {
                assertTrue(board.isEmpty(i+1, i+1));
        }



    }







}