package NetworkScrabble.Utils.Exceptions;

public class InvalidMainWordException extends InvalidMoveException {

    public InvalidMainWordException(String msg) {
        super(msg);
    }
}
