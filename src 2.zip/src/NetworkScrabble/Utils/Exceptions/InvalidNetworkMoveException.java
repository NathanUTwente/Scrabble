package NetworkScrabble.Utils.Exceptions;

public class InvalidNetworkMoveException extends InvalidMoveException {
    public InvalidNetworkMoveException(String msg) {
        super(msg);
    }
}
