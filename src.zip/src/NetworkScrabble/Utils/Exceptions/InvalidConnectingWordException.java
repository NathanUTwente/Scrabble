package NetworkScrabble.Utils.Exceptions;

public class InvalidConnectingWordException extends InvalidMoveException {

    public InvalidConnectingWordException(String msg) {
        super(msg);
    }
}
