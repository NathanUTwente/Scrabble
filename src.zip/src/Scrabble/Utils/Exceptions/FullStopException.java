package Scrabble.Utils.Exceptions;

public class FullStopException extends InvalidMoveException {

    public FullStopException(String msg) {
        super(msg);
    }
}
