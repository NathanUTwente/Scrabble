package Scrabble.Utils.Exceptions;

public class NotCenteredException extends InvalidMoveException{

    public NotCenteredException(String msg){
        super(msg);
    }
}
